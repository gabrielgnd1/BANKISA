﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISA_BANK.DBCLASS
{
    internal class Nasabah
    {
        #region datamember
        private string id;
        private string nama;
        private DateTime ttl;
        private string nik;
        private string no_telepon;
        #endregion
    }
}
