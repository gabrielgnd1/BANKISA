﻿namespace ISA_BANK
{
    partial class FormTransfer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTransfer = new System.Windows.Forms.Label();
            this.gbFrom = new System.Windows.Forms.GroupBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblCurBalance = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAccNum = new System.Windows.Forms.TextBox();
            this.lblAccNum = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.lblCustName = new System.Windows.Forms.Label();
            this.gbTo = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.lblTrfAmmount = new System.Windows.Forms.Label();
            this.btnTranfer = new System.Windows.Forms.Button();
            this.gbFrom.SuspendLayout();
            this.gbTo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTransfer
            // 
            this.lblTransfer.AutoSize = true;
            this.lblTransfer.BackColor = System.Drawing.Color.Transparent;
            this.lblTransfer.CausesValidation = false;
            this.lblTransfer.Font = new System.Drawing.Font("Microsoft YaHei", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransfer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTransfer.Location = new System.Drawing.Point(33, 45);
            this.lblTransfer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTransfer.Name = "lblTransfer";
            this.lblTransfer.Size = new System.Drawing.Size(220, 50);
            this.lblTransfer.TabIndex = 9;
            this.lblTransfer.Text = "TRANSFER";
            // 
            // gbFrom
            // 
            this.gbFrom.Controls.Add(this.btnSearch);
            this.gbFrom.Controls.Add(this.label3);
            this.gbFrom.Controls.Add(this.textBox1);
            this.gbFrom.Controls.Add(this.lblCurBalance);
            this.gbFrom.Controls.Add(this.label2);
            this.gbFrom.Controls.Add(this.txtAccNum);
            this.gbFrom.Controls.Add(this.lblAccNum);
            this.gbFrom.Controls.Add(this.label1);
            this.gbFrom.Controls.Add(this.txtCustName);
            this.gbFrom.Controls.Add(this.lblCustName);
            this.gbFrom.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbFrom.Location = new System.Drawing.Point(42, 119);
            this.gbFrom.Name = "gbFrom";
            this.gbFrom.Size = new System.Drawing.Size(913, 282);
            this.gbFrom.TabIndex = 10;
            this.gbFrom.TabStop = false;
            this.gbFrom.Text = "From";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(761, 228);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(102, 37);
            this.btnSearch.TabIndex = 13;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(274, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 36);
            this.label3.TabIndex = 12;
            this.label3.Text = ":";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox1.Location = new System.Drawing.Point(314, 170);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(549, 34);
            this.textBox1.TabIndex = 11;
            // 
            // lblCurBalance
            // 
            this.lblCurBalance.AutoSize = true;
            this.lblCurBalance.BackColor = System.Drawing.Color.Transparent;
            this.lblCurBalance.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurBalance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblCurBalance.Location = new System.Drawing.Point(23, 166);
            this.lblCurBalance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCurBalance.Name = "lblCurBalance";
            this.lblCurBalance.Size = new System.Drawing.Size(226, 36);
            this.lblCurBalance.TabIndex = 10;
            this.lblCurBalance.Text = "Current Balance";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(274, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 36);
            this.label2.TabIndex = 9;
            this.label2.Text = ":";
            // 
            // txtAccNum
            // 
            this.txtAccNum.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccNum.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtAccNum.Location = new System.Drawing.Point(314, 116);
            this.txtAccNum.Margin = new System.Windows.Forms.Padding(4);
            this.txtAccNum.Name = "txtAccNum";
            this.txtAccNum.Size = new System.Drawing.Size(549, 34);
            this.txtAccNum.TabIndex = 8;
            // 
            // lblAccNum
            // 
            this.lblAccNum.AutoSize = true;
            this.lblAccNum.BackColor = System.Drawing.Color.Transparent;
            this.lblAccNum.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccNum.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblAccNum.Location = new System.Drawing.Point(23, 112);
            this.lblAccNum.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAccNum.Name = "lblAccNum";
            this.lblAccNum.Size = new System.Drawing.Size(244, 36);
            this.lblAccNum.TabIndex = 7;
            this.lblAccNum.Text = "Account Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(274, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 36);
            this.label1.TabIndex = 6;
            this.label1.Text = ":";
            // 
            // txtCustName
            // 
            this.txtCustName.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtCustName.Location = new System.Drawing.Point(314, 59);
            this.txtCustName.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.Size = new System.Drawing.Size(549, 34);
            this.txtCustName.TabIndex = 5;
            // 
            // lblCustName
            // 
            this.lblCustName.AutoSize = true;
            this.lblCustName.BackColor = System.Drawing.Color.Transparent;
            this.lblCustName.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblCustName.Location = new System.Drawing.Point(23, 55);
            this.lblCustName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustName.Name = "lblCustName";
            this.lblCustName.Size = new System.Drawing.Size(233, 36);
            this.lblCustName.TabIndex = 4;
            this.lblCustName.Text = "Customer Name";
            // 
            // gbTo
            // 
            this.gbTo.Controls.Add(this.button1);
            this.gbTo.Controls.Add(this.label4);
            this.gbTo.Controls.Add(this.textBox2);
            this.gbTo.Controls.Add(this.label5);
            this.gbTo.Controls.Add(this.label6);
            this.gbTo.Controls.Add(this.textBox3);
            this.gbTo.Controls.Add(this.label7);
            this.gbTo.Controls.Add(this.label8);
            this.gbTo.Controls.Add(this.textBox4);
            this.gbTo.Controls.Add(this.label9);
            this.gbTo.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbTo.Location = new System.Drawing.Point(42, 444);
            this.gbTo.Name = "gbTo";
            this.gbTo.Size = new System.Drawing.Size(913, 282);
            this.gbTo.TabIndex = 11;
            this.gbTo.TabStop = false;
            this.gbTo.Text = "To";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(761, 228);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 37);
            this.button1.TabIndex = 13;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(274, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 36);
            this.label4.TabIndex = 12;
            this.label4.Text = ":";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox2.Location = new System.Drawing.Point(314, 170);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(549, 34);
            this.textBox2.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(23, 166);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(226, 36);
            this.label5.TabIndex = 10;
            this.label5.Text = "Current Balance";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(274, 112);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 36);
            this.label6.TabIndex = 9;
            this.label6.Text = ":";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox3.Location = new System.Drawing.Point(314, 116);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(549, 34);
            this.textBox3.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(23, 112);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(244, 36);
            this.label7.TabIndex = 7;
            this.label7.Text = "Account Number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(274, 55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 36);
            this.label8.TabIndex = 6;
            this.label8.Text = ":";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox4.Location = new System.Drawing.Point(314, 59);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(549, 34);
            this.textBox4.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(23, 55);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(233, 36);
            this.label9.TabIndex = 4;
            this.label9.Text = "Customer Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(316, 768);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 32);
            this.label10.TabIndex = 16;
            this.label10.Text = ":";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox5.Location = new System.Drawing.Point(356, 772);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(549, 34);
            this.textBox5.TabIndex = 15;
            // 
            // lblTrfAmmount
            // 
            this.lblTrfAmmount.AutoSize = true;
            this.lblTrfAmmount.BackColor = System.Drawing.Color.Transparent;
            this.lblTrfAmmount.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrfAmmount.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTrfAmmount.Location = new System.Drawing.Point(43, 768);
            this.lblTrfAmmount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTrfAmmount.Name = "lblTrfAmmount";
            this.lblTrfAmmount.Size = new System.Drawing.Size(266, 36);
            this.lblTrfAmmount.TabIndex = 14;
            this.lblTrfAmmount.Text = "Transfer Ammount";
            // 
            // btnTranfer
            // 
            this.btnTranfer.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTranfer.Location = new System.Drawing.Point(803, 833);
            this.btnTranfer.Name = "btnTranfer";
            this.btnTranfer.Size = new System.Drawing.Size(102, 37);
            this.btnTranfer.TabIndex = 14;
            this.btnTranfer.Text = "Transfer";
            this.btnTranfer.UseVisualStyleBackColor = true;
            // 
            // FormTransfer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(1010, 898);
            this.Controls.Add(this.btnTranfer);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.gbTo);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.lblTrfAmmount);
            this.Controls.Add(this.gbFrom);
            this.Controls.Add(this.lblTransfer);
            this.Name = "FormTransfer";
            this.Text = "Transfer";
            this.gbFrom.ResumeLayout(false);
            this.gbFrom.PerformLayout();
            this.gbTo.ResumeLayout(false);
            this.gbTo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTransfer;
        private System.Windows.Forms.GroupBox gbFrom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAccNum;
        private System.Windows.Forms.Label lblAccNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.Label lblCustName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblCurBalance;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.GroupBox gbTo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label lblTrfAmmount;
        private System.Windows.Forms.Button btnTranfer;
    }
}